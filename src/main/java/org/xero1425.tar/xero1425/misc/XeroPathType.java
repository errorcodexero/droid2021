package org.xero1425.misc;

public enum XeroPathType {
    SwervePathFollowing,
    SwervePurePursuit,
    TankPathFollowing,
    TankPurePursuit
}
