package org.xero1425.base.motorsubsystem ;

public class EncoderConfigException extends Exception
{
    static final long serialVersionUID = 42 ;
        
    public EncoderConfigException(String msg) {
        super(msg) ;
    }
}
