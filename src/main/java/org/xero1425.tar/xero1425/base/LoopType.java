package org.xero1425.base  ;

public enum LoopType
{
    Teleop,
    Autonomous,
    Test,
    Disabled
} ;
