package org.xero1425.base.controllers;

import org.xero1425.base.XeroRobot;

public class TestController extends BaseController
{
    public TestController(XeroRobot robot, String name) {
        super(robot, name) ;
    }

    @Override
    public void init() {

    }

    @Override
    public void run() {
        
    }
} ;