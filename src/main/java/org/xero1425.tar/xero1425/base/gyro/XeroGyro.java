package org.xero1425.base.gyro;

public interface XeroGyro {
    public boolean isConnected() ;
    public double getYaw() ;
    public double getAngle() ;
}
